﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Centroide
{
    internal class Canvas
    {
        Bitmap bitmap;
        Graphics g;
        PictureBox PCT_CANVA;

        private double anguloRotacion = 0; // Ángulo de rotación en grados
        double factorDeEscala = 1;
        int tranX = 0,tranY = 0;


        private bool mostrarTriangulo = true;
        private bool mostrarCuadrado = true;

        public void MostrarTriangulo()
        {
            mostrarTriangulo = true;
            mostrarCuadrado = false;
            Render();
        }

        public void MostrarCuadrado()
        {
            mostrarTriangulo = false;
            mostrarCuadrado = true;
            Render();
        }

        

        public void ActualizarAnguloRotacion(double nuevoAngulo)
        {
            anguloRotacion = nuevoAngulo;
        }

        public void ActualizarEscalado(double nuevoFactor)
        {
            factorDeEscala = nuevoFactor;
        }

        public void MoverFigura(int transX, int transY)
        {
            tranX += transX;
            tranY += transY;


            Render();
        }


        public Canvas(Bitmap bmp, PictureBox pctCanvas) 
        {
            bitmap = bmp;
            g = Graphics.FromImage(bitmap);
            PCT_CANVA = pctCanvas;
        }

        public void CentrarFigura()
        {
            
            int nuevoCentroX = bitmap.Width / 2;
            int nuevoCentroY = bitmap.Height / 2;

            
            int transX = nuevoCentroX - tranX;
            int transY = nuevoCentroY - tranY;

            
            MoverFigura(transX, transY);
        }


        
            public void Render()
            {
                g.Clear(Color.Transparent);

                if (mostrarCuadrado)
                {
                    // Renderiza el cuadrado
                    List<Point> puntosCuadrado = Figure.CrearCuadrado(1);
                    Figure.EscalarFigura(puntosCuadrado, factorDeEscala);
                    Point pivoteRotacionCuadrado = puntosCuadrado[0];
                    Figure.RotarFigura(puntosCuadrado, anguloRotacion, pivoteRotacionCuadrado);
                    Figure.TrasladarFigura(puntosCuadrado, tranX - pivoteRotacionCuadrado.X, tranY - pivoteRotacionCuadrado.Y);

                    using (Pen redPen = new Pen(Color.Red))
                    {
                        g.DrawLine(redPen, puntosCuadrado[0], puntosCuadrado[1]);
                        g.DrawLine(redPen, puntosCuadrado[1], puntosCuadrado[2]);
                        g.DrawLine(redPen, puntosCuadrado[2], puntosCuadrado[3]);
                        g.DrawLine(redPen, puntosCuadrado[3], puntosCuadrado[0]);
                    }
                }

                if (mostrarTriangulo)
                {
                    
                    List<Point> puntosTriangulo = Figure.CrearTriangulo(1);
                    Figure.EscalarFigura(puntosTriangulo, factorDeEscala);
                    Point pivoteRotacionTriangulo = puntosTriangulo[0];
                    Figure.RotarFigura(puntosTriangulo, anguloRotacion, pivoteRotacionTriangulo);
                    Figure.TrasladarFigura(puntosTriangulo, tranX - pivoteRotacionTriangulo.X, tranY - pivoteRotacionTriangulo.Y);

                    using (Pen purplePen = new Pen(Color.Purple))
                    {
                        g.DrawLine(purplePen, puntosTriangulo[0], puntosTriangulo[1]);
                        g.DrawLine(purplePen, puntosTriangulo[1], puntosTriangulo[2]);
                        g.DrawLine(purplePen, puntosTriangulo[2], puntosTriangulo[0]);
                    }
                }

                PCT_CANVA.Invalidate();
        }







    }
}
