using System.Drawing;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Centroide
{
    public partial class Form1 : Form
    {
        Canvas canvas;
        Line line;
        Bitmap bmp;
        Graphics g;


        public Form1()
        {
            InitializeComponent();
            Init();

        }

        private void Init()
        {
            if (canvas == null)
            {
                bmp = new Bitmap(PCT_CANVA.Width, PCT_CANVA.Height);
                g = Graphics.FromImage(bmp);
                PCT_CANVA.Image = bmp;
                canvas = new Canvas(bmp, PCT_CANVA);
                line = new Line(bmp, PCT_CANVA);
            }

            canvas.Render();
            line.RenderLine(g);
            PCT_CANVA.Invalidate();
        }





        private void PCT_CANVAS_Click(object sender, EventArgs e)
        {

        }



        private void button1_Click(object sender, EventArgs e)
        {

            ActualizarAnguloDesdeTextBox();
            ActualizarEscalaDesdeTextBox();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //ActualizarAnguloDesdeTextBox();

        }

        private void ActualizarAnguloDesdeTextBox()
        {
            // Obtener el �ngulo ingresado desde el TextBox
            if (double.TryParse(txtAngulo.Text, out double angulo))
            {
                // Actualizar el �ngulo de rotaci�n en el objeto canvas
                canvas.ActualizarAnguloRotacion(angulo);
                // Volver a renderizar el Canvas
                canvas.Render();
                line.RenderLine(g);
                PCT_CANVA.Invalidate();
            }

        }

        private void ActualizarEscalaDesdeTextBox()
        {
            // Obtener el factor de escala ingresado desde el TextBox
            if (double.TryParse(txtEscala.Text, out double factor))
            {
                // Actualizar el factor de escala en el objeto canvas
                canvas.ActualizarEscalado(factor);
                // Volver a renderizar el Canvas
                canvas.Render();
                line.RenderLine(g);
                PCT_CANVA.Invalidate();
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {


            int desplazamientoX = 100; // por ejemplo, desplaza 10 p�xeles en X

            // Actualizar la posici�n de la figura en el eje x
            canvas.MoverFigura(desplazamientoX, 0); // Solo movemos en el eje X

            // Volver a renderizar el Canvas y la l�nea
            canvas.Render();
            line.RenderLine(g);
            PCT_CANVA.Invalidate();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            canvas.CentrarFigura();
            canvas.Render();
            line.RenderLine(g);
            PCT_CANVA.Invalidate();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            int desplazamientoX = -100; 
            canvas.MoverFigura(desplazamientoX, 0); 
            canvas.Render();
            line.RenderLine(g);
            PCT_CANVA.Invalidate();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            int desplazamientoY = 100; 
            canvas.MoverFigura(0, desplazamientoY); 


            canvas.Render();
            line.RenderLine(g);
            PCT_CANVA.Invalidate();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int desplazamientoY = -100; // por ejemplo, desplaza 10 p�xeles en X

            // Actualizar la posici�n de la figura en el eje x
            canvas.MoverFigura(0, desplazamientoY); // Solo movemos en el eje X

            // Volver a renderizar el Canvas y la l�nea
            canvas.Render();
            line.RenderLine(g);
            PCT_CANVA.Invalidate();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            canvas.ActualizarAnguloRotacion(0);
            canvas.ActualizarEscalado(1);
            canvas.MostrarTriangulo();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            canvas.ActualizarAnguloRotacion(0);
            canvas.ActualizarEscalado(1);
            canvas.MostrarCuadrado();
        }
    }
}
