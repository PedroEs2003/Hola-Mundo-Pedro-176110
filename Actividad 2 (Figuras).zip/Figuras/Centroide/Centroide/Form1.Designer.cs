﻿namespace Centroide
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            PCT_CANVA = new PictureBox();
            button8 = new Button();
            button7 = new Button();
            button6 = new Button();
            button4 = new Button();
            button5 = new Button();
            button3 = new Button();
            button2 = new Button();
            txtEscala = new TextBox();
            label2 = new Label();
            txtAngulo = new TextBox();
            label1 = new Label();
            button1 = new Button();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)PCT_CANVA).BeginInit();
            SuspendLayout();
            // 
            // PCT_CANVA
            // 
            PCT_CANVA.BackColor = SystemColors.Desktop;
            PCT_CANVA.Location = new Point(116, -1);
            PCT_CANVA.Name = "PCT_CANVA";
            PCT_CANVA.Size = new Size(1353, 637);
            PCT_CANVA.TabIndex = 0;
            PCT_CANVA.TabStop = false;
            PCT_CANVA.Click += PCT_CANVAS_Click;
            // 
            // button8
            // 
            button8.BackColor = Color.FromArgb(192, 0, 0);
            button8.Location = new Point(9, 47);
            button8.Name = "button8";
            button8.Size = new Size(87, 29);
            button8.TabIndex = 10;
            button8.Text = "Cuadrado";
            button8.UseVisualStyleBackColor = false;
            button8.Click += button8_Click;
            // 
            // button7
            // 
            button7.BackColor = Color.Purple;
            button7.Location = new Point(9, 12);
            button7.Name = "button7";
            button7.Size = new Size(87, 29);
            button7.TabIndex = 9;
            button7.Text = "Triangulo";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // button6
            // 
            button6.Location = new Point(44, 420);
            button6.Name = "button6";
            button6.Size = new Size(21, 29);
            button6.TabIndex = 8;
            button6.Text = "^";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button4
            // 
            button4.Location = new Point(5, 455);
            button4.Name = "button4";
            button4.Size = new Size(35, 29);
            button4.TabIndex = 2;
            button4.Text = "<-";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Location = new Point(44, 490);
            button5.Name = "button5";
            button5.Size = new Size(21, 32);
            button5.TabIndex = 3;
            button5.Text = "v";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button3
            // 
            button3.Location = new Point(44, 455);
            button3.Name = "button3";
            button3.Size = new Size(23, 29);
            button3.TabIndex = 7;
            button3.Text = "o";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.Location = new Point(73, 455);
            button2.Name = "button2";
            button2.Size = new Size(37, 29);
            button2.TabIndex = 2;
            button2.Text = "->";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // txtEscala
            // 
            txtEscala.Location = new Point(12, 224);
            txtEscala.Name = "txtEscala";
            txtEscala.Size = new Size(61, 27);
            txtEscala.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 136);
            label2.Name = "label2";
            label2.Size = new Size(67, 20);
            label2.TabIndex = 3;
            label2.Text = "ANGULO";
            // 
            // txtAngulo
            // 
            txtAngulo.Location = new Point(12, 159);
            txtAngulo.Name = "txtAngulo";
            txtAngulo.Size = new Size(61, 27);
            txtAngulo.TabIndex = 2;
            txtAngulo.TextChanged += textBox1_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 201);
            label1.Name = "label1";
            label1.Size = new Size(61, 20);
            label1.TabIndex = 1;
            label1.Text = "ESCALA";
            // 
            // button1
            // 
            button1.Location = new Point(9, 257);
            button1.Name = "button1";
            button1.Size = new Size(64, 26);
            button1.TabIndex = 0;
            button1.Text = "OK";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = Color.Yellow;
            label3.Location = new Point(-1, 525);
            label3.Name = "label3";
            label3.Size = new Size(111, 20);
            label3.TabIndex = 11;
            label3.Text = "Se centra con o";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlDarkDark;
            ClientSize = new Size(1468, 635);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(txtAngulo);
            Controls.Add(label2);
            Controls.Add(txtEscala);
            Controls.Add(button7);
            Controls.Add(button8);
            Controls.Add(PCT_CANVA);
            Controls.Add(button3);
            Controls.Add(button4);
            Controls.Add(button1);
            Controls.Add(button2);
            Controls.Add(button6);
            Controls.Add(button5);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)PCT_CANVA).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox PCT_CANVA;
        private Label label1;
        private Button button1;
        private TextBox txtAngulo;
        private TextBox txtEscala;
        private Label label2;
        private Button button2;
        private Button button3;
        private Button button6;
        private Button button4;
        private Button button5;
        private Button button7;
        private Button button8;
        private Label label3;
    }
}
